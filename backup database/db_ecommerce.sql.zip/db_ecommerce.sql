-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2021 at 11:14 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(17) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password_akses` varchar(30) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `role_admin` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password_akses`, `nama_lengkap`, `role_admin`) VALUES
(1, 'admin', 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` varchar(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `nama_kategori`) VALUES
('KAT01', 'ADIDAS ULTRABOOST'),
('KAT02', 'BALENCIAGA'),
('KAT03', 'NEW BALANCE'),
('KAT04', 'NIKE AIRFORCE'),
('KAT05', 'NIKE AIRJORDAN'),
('KAT06', 'NIKE AIRMAX');

-- --------------------------------------------------------

--
-- Table structure for table `tb_order`
--

CREATE TABLE `tb_order` (
  `id_order` varchar(10) NOT NULL,
  `id_produk` varchar(10) NOT NULL,
  `id_pelanggan` varchar(17) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `ukuran_produk` varchar(5) NOT NULL,
  `quantity_produk` int(11) NOT NULL,
  `harga_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_order`
--

INSERT INTO `tb_order` (`id_order`, `id_produk`, `id_pelanggan`, `nama_produk`, `ukuran_produk`, `quantity_produk`, `harga_produk`) VALUES
('OR001', 'AD235', '1271060211990004', 'Adidas Ultraboost Ace', 'L', 1, 325000),
('OR001', 'GMX01', '1271060211990004', 'Geoff Max Authentic Black Gum', 'L', 1, 300000),
('OR002', 'AD235', '12710602119900012', 'Adida Ultraboost Ace', 'L', 1, 325000),
('OR002', 'AD345', '12710602119900012', 'Adidas Ultraboost Black White', 'L', 1, 345000),
('OR003', 'GMX01', '12710602119900012', 'Geoff Max Authentic Black Gum', 'L', 1, 300000),
('OR003', 'GMX01', '12710602119900012', 'Geoff Max Authentic Black Gum', 'L', 1, 300000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` varchar(17) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password_akses` varchar(30) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat_lengkap` varchar(500) NOT NULL,
  `nomor_rekening` varchar(20) NOT NULL,
  `nama_bank` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id_pelanggan`, `email`, `password_akses`, `nama_lengkap`, `tanggal_lahir`, `alamat_lengkap`, `nomor_rekening`, `nama_bank`) VALUES
('123456789101', 'putrihidayah121@gmail.com', 'putri123', 'Putri Hidayah', '1998-11-16', 'Jl.Klambir 5', '', 'Bank Rakyat Indonesia (BRI)'),
('12710602119900012', 'asd@gmail.com', 'asd', 'Putri Hidayah', '2021-04-01', 'asdasd', '8280377630', 'Bank Central Asia (BCA)'),
('1271060211990004', 'ryansyehan02@gmail.com', '02111999', 'Rian Syehan Pratama', '1999-11-02', 'Jl.Bilal Ujung Gg.Setia No.7, Pulo Brayan Darat 1, Medan Timur, Sumatera Utara 20239', '8280377610', 'Bank Central Asia (BCA)');

-- --------------------------------------------------------

--
-- Table structure for table `tb_perusahaan`
--

CREATE TABLE `tb_perusahaan` (
  `id_usaha` varchar(20) NOT NULL,
  `nama_usaha` varchar(100) NOT NULL,
  `alamat_usaha` varchar(500) NOT NULL,
  `nama_pemilik` varchar(50) NOT NULL,
  `nomor_rekening_usaha` varchar(20) NOT NULL,
  `nama_bank_usaha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_perusahaan`
--

INSERT INTO `tb_perusahaan` (`id_usaha`, `nama_usaha`, `alamat_usaha`, `nama_pemilik`, `nomor_rekening_usaha`, `nama_bank_usaha`) VALUES
('ECM01', 'ECommerce Shoes', 'Jl.Cempaka No.61, Kec.Medan Helvetia, Medan, Sumatera Utara, 20125', 'Putri Hidayah', '82803377821', 'Bank Central Asia (BCA)');

-- --------------------------------------------------------

--
-- Table structure for table `tb_produk`
--

CREATE TABLE `tb_produk` (
  `id_produk` varchar(10) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `kategori_produk` varchar(50) NOT NULL,
  `stok_produk` int(11) NOT NULL,
  `ukuran_produk` varchar(5) NOT NULL,
  `deskripsi_produk` varchar(500) NOT NULL,
  `gambar_produk` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_produk`
--

INSERT INTO `tb_produk` (`id_produk`, `nama_produk`, `harga_produk`, `kategori_produk`, `stok_produk`, `ukuran_produk`, `deskripsi_produk`, `gambar_produk`) VALUES
('AD01', 'ADIDAS UltraBoost Woman', 345000, 'ADIDAS ULTRABOOST', 20, '36-41', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori\r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD01'),
('AD02', 'ADIDAS UltraBoost Woman', 345000, 'ADIDAS ULTRABOOST', 20, '36-41', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD02'),
('AD03', 'Adidas Ultraboost', 235000, 'ADIDAS ULTRABOOST', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD03'),
('AD04', 'AD1D4S UltraBoost 4.0', 335000, 'ADIDAS ULTRABOOST', 20, '36-41', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD04'),
('AD05', 'ADIDAS Ultraboost', 305000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD05'),
('AD06', 'AD1D4S Ultraboost Ace 16 Man', 325000, 'ADIDAS ULTRABOOST', 20, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori\r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n\r\n\r\n', 'AD06'),
('AD07', 'ADIDAS Ultraboost 4.0 â€˜Dash Greyâ€™ ', 650000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n\r\n', 'AD07'),
('AD08', 'AD1D4S Ultraboost 20 â€œ Core Black Gold â€œ ', 530000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n\r\n', 'AD08'),
('AD09', 'ADIDAS Ace 16+ Purecontrol Ultraboost â€˜All Blackâ€™', 590000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD09'),
('AD10', 'ADIDAS Ultraboost 3.0 â€˜Triple Blackâ€™', 540000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n\r\n', 'AD10'),
('AD11', 'AD1D4S Ultraboost 3.0 â€˜Full Whiteâ€™', 500000, 'ADIDAS ULTRABOOST', 20, '36-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AD11'),
('AD12', 'AD1D4S Ultraboost 20 â€˜White Blackâ€™', 530000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n\r\n\r\n', 'AD12'),
('AD13', 'AD1D4S Ultraboost 4.0 Orca', 620000, 'ADIDAS ULTRABOOST', 20, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AD13'),
('AJ01', 'N1KE Air Jordan Obsidian', 345000, 'NIKE AIRJORDAN', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AJ01'),
('AJ02', 'N1KE Air Jordan Low', 305000, 'NIKE AIRJORDAN', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AJ02'),
('AJ03', 'N1KE Air Jordan 1 Retro High For Man', 275000, 'NIKE AIRJORDAN', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AJ03'),
('AJ04', 'N1KE Air Jordan 4', 325000, 'NIKE AIRJORDAN', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AJ04'),
('AJ05', 'N1KE Air Jordan 1 High " Obsidian University Blue "', 520000, 'NIKE AIRJORDAN', 15, '36-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ05'),
('AJ06', 'N1KE Air Jordan 1 Retro High " Blue Chill "', 690000, 'NIKE AIRJORDAN', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ06'),
('AJ07', 'N1KE Air Jordan 1 Mid "Laser Blue" (S7)', 580000, 'NIKE AIRJORDAN', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ07'),
('AJ08', 'N1KE Air Jordan 1 High "Black Satin" ', 580000, 'NIKE AIRJORDAN', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ08'),
('AJ09', 'N1KE Air Jordan 1 Low â€˜Black Toe" ', 480000, 'ADIDAS ULTRABOOST', 15, '37-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ09'),
('AJ10', 'N1KE Air Jordan 1 High â€˜Black Toe" ', 530000, 'NIKE AIRJORDAN', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ10'),
('AJ11', 'N1KE Air Jordan 1 Panda " Black White " ', 530000, 'NIKE AIRJORDAN', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ11'),
('AJ12', 'N1KE Air Jordan 4 â€œwhat the" ', 550000, 'NIKE AIRJORDAN', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'AJ12'),
('AX01', 'N1KE Airmax 720 Import', 295000, 'NIKE AIRMAX', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AX01'),
('AX02', 'N1KE Airmax 270', 355000, 'NIKE AIRMAX', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AX02'),
('AX03', 'N1KE Airmax 720', 355000, 'NIKE AIRMAX', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AX03'),
('AX04', 'N1KE Airmax 720', 345000, 'NIKE AIRMAX', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'AX04'),
('AX05', 'N1KE Airmax 270 Seattle Home " Sonic "', 670000, 'NIKE AIRMAX', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AX05'),
('AX06', 'N1KE Airmax 270 " Washed coral"', 500000, 'NIKE AIRMAX', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AX06'),
('AX07', 'N1KE Airmax 720 " Black White "', 620000, 'NIKE AIRMAX', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AX07'),
('AX08', 'N1KE Airmax 97 Lx " Black  Active Fuchsia "', 560000, 'NIKE AIRMAX', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AX08'),
('AX09', 'N1KE Airmax 97 " Corduroy Pink "', 540000, 'NIKE AIRMAX', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'AX09'),
('BC01', 'BALENCIAGA Woman', 295000, 'ADIDAS ULTRABOOST', 20, '37-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC01'),
('BC02', 'BALENCIAGA Triple S Man', 325000, 'BALENCIAGA', 20, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC02'),
('BC03', 'BALENCIAGA Triple S For Woman', 375000, 'BALENCIAGA', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC03'),
('BC05', 'BALENCIAGA Triple S For Woman', 375000, 'BALENCIAGA', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC05'),
('BC06', 'B4LENC1AGA Triple S For Woman', 375000, 'BALENCIAGA', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC06'),
('BC07', 'BALENCIAGA Triple S For Woman', 375000, 'BALENCIAGA', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC07'),
('BC08', 'BALENCIAGA Triple S For Woman', 375000, 'BALENCIAGA', 20, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC08'),
('BC09', 'BALENCIAGA Shoes', 325000, 'BALENCIAGA', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'BC09'),
('BC10', 'BALLENCIAGA Triple S " Black Purple " ', 750000, 'BALENCIAGA', 15, '37-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'BC10'),
('BC11', 'B4LENC1AGA Triple S " Bred Black Red " ', 730000, 'BALENCIAGA', 15, '37-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'BC11'),
('BC12', 'B4LENC1AGA Triple S Clear Sole " Pink " ', 830000, 'BALENCIAGA', 10, '37-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'BC12'),
('BC13', 'B4LENC1AGA Triple S â€œ White â€œ ', 750000, 'BALENCIAGA', 15, '37-41', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan\r\n', 'BC13'),
('NB01', 'NEW BALANCE For Man', 275000, 'NEW BALANCE', 15, '39-43', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan\r\n', 'NB01'),
('NB02', 'NEW BALANCE', 245000, 'NEW BALANCE', 15, '36-43', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB02'),
('NB03', 'NEW BALANCE', 245000, 'NEW BALANCE', 15, '36-43', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB03'),
('NB04', 'NEW BALANCE', 245000, 'NEW BALANCE', 15, '36-43', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB04'),
('NB05', 'NEW BALANCE', 245000, 'NEW BALANCE', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB05'),
('NB06', 'NEW BALANCE', 245000, 'NEW BALANCE', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB06'),
('NB07', 'NEW BALANCE Woman', 245000, 'NEW BALANCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB07'),
('NB08', 'NEW BALANCE Woman', 335000, 'NEW BALANCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NB08'),
('NB09', 'NEW B4LANCE 574 GNC " Triple White "', 615000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB09'),
('NB10', 'NEW B4LANCE 574 Sport " Flight path " ', 600000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB10'),
('NB11', 'NEW B4L4NCE 2003R â€˜Light Greyâ€™', 650000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB11'),
('NB12', 'NEW B4LANCE 574S " All Black "', 600000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB12'),
('NB14', 'NEW B4LANCE MS247TG " Tritium Pack "', 570000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB14'),
('NB15', 'NEW B4LANCE 1500 Surplus Pack', 590000, 'NEW BALANCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB15'),
('NB16', 'NEW B4LANCE 574', 540000, 'NEW BALANCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NB16'),
('NF01', 'N1KE Airforce Untility', 285000, 'NIKE AIRFORCE', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NF01'),
('NF02', 'N1KE Airforce â€˜ All White â€˜', 375000, 'NIKE AIRFORCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NF02'),
('NF03', 'N1KE Air Force 1 for Man', 385000, 'NIKE AIRFORCE', 15, '39-44', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NF03'),
('NF04', 'N1KE Airforce 1 Brown', 310000, 'NIKE AIRFORCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang Grade Ori \r\nâ€¢ Garansi 100% uang kembali jika barang tidak sampai tujuan', 'NF04'),
('NF05', 'N1KE Air Force 1 Low " Wheat Mocha â€œ ', 600000, 'NIKE AIRFORCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF05'),
('NF06', 'N1KE Airforce 1 Crest Logo " White "', 500000, 'ADIDAS ULTRABOOST', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF06'),
('NF07', 'N1KE Airforce 1 07 Lx Bio "Beige Metallic Gold"', 530000, 'NIKE AIRFORCE', 15, '36-40', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF07'),
('NF08', 'Off White x Nike Air Force 1 MCA', 890000, 'NIKE AIRFORCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF08'),
('NF09', 'N1KE Airforce 1 Low X Off White " Black "', 740000, 'NIKE AIRFORCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF09'),
('NF10', 'N1KE Airforce 1 Utility " Volt "', 590000, 'NIKE AIRFORCE', 15, '39-45', 'â€¢ 100% Realpict\r\nâ€¢ Kualitas barang DIJAMIN terbaik (BNIB PREMIUM HIGH QUALITY)\r\nâ€¢ GARANSI 100% uang kembali jika barang tidak sampai tujuan', 'NF10');

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_transaksi` varchar(10) NOT NULL,
  `id_order` varchar(10) NOT NULL,
  `id_pelanggan` varchar(17) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `waktu_transaksi` time NOT NULL,
  `total_transaksi` int(11) NOT NULL,
  `status_transaksi` varchar(20) NOT NULL,
  `nomor_rekening_pelanggan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_transaksi`, `id_order`, `id_pelanggan`, `tanggal_transaksi`, `waktu_transaksi`, `total_transaksi`, `status_transaksi`, `nomor_rekening_pelanggan`) VALUES
('TR001', 'OR001', '1271060211990004', '2021-04-05', '12:26:23', 625000, 'Dibayar', '8280377610'),
('TR002', 'OR002', '1271060211990004', '2021-04-01', '05:02:03', 670000, 'Belum Dibayar', '8280377610'),
('TR003', 'OR003', '12710602119900012', '2021-04-02', '08:05:00', 600000, 'Belum Dibayar', '8280377630');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `tb_perusahaan`
--
ALTER TABLE `tb_perusahaan`
  ADD PRIMARY KEY (`id_usaha`);

--
-- Indexes for table `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
